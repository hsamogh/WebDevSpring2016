(function(){
    angular
        .module("FormMakerApp", ["ngRoute"]);
})();