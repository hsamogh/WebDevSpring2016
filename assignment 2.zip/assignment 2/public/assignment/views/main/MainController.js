/**
 * Created by Amogh on 3/4/2016.
 */
(function(){
    angular
        .module("FormMakerApp")
        .controller("MainController",function($scope,$location){
            $scope.location=$location;
        })

})();